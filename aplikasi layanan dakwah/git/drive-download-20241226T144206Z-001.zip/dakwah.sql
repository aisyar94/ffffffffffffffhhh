-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 23, 2024 at 02:47 PM
-- Server version: 10.4.32-MariaDB-log
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dakwah`
--

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `event_id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `description` text NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `location` varchar(100) NOT NULL,
  `status` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`event_id`, `name`, `description`, `date`, `location`, `status`) VALUES
(2, 'Dakwa Islamiah', 'nananavdsvds', '2024-12-23', 'Masjid Agung Makassar', 'Belum DiMulai'),
(4, 'svds', 'bvasvadsgaesgas', '2024-12-23', 'bvdfavdvdsvds', 'Belum DiMulai'),
(5, 'vasva', 'dsbvdabvas', '2024-12-23', 'basdbabgdabdfhrehre', 'Belum DiMulai');

-- --------------------------------------------------------

--
-- Table structure for table `event_kon`
--

CREATE TABLE `event_kon` (
  `id` int(11) NOT NULL,
  `participant_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `konten`
--

CREATE TABLE `konten` (
  `id_konten` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `link` varchar(150) NOT NULL,
  `description` text NOT NULL,
  `maker` varchar(25) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `konten`
--

INSERT INTO `konten` (`id_konten`, `title`, `link`, `description`, `maker`, `date`) VALUES
(2, 'cvds', 'pass', 'vdsvds', 'pas', '2024-12-23'),
(3, 'csss', 'cs', 'cas', 'cssss', '2024-12-23'),
(4, 'vsda', 'vsd', 'vas', 'va', '2024-12-23'),
(5, 'vdsvbabfs', 'abasbsas', 'bdfbdfvsavdasvg', 'bdfbdsbasbv', '2024-12-23'),
(7, 'vas', 'vas', 'vdas', 'vsa', '2024-12-23'),
(8, 'vas', 'bvas', 'vas', 'vdasvd', '2024-12-23'),
(9, 'Title', 'Link', 'Description', 'maker', '2024-12-23'),
(13, 'bv', 'bas', 'basvdsvdsvd', 'ndak tahu', '2024-12-23'),
(15, 'vfsevfs', 'vdsvdsd', 'vdsvdsvsd', 'bvdsvdsvdavas', '2024-12-23');

-- --------------------------------------------------------

--
-- Table structure for table `partisipant`
--

CREATE TABLE `partisipant` (
  `participant_id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `gender` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `event_kon`
--
ALTER TABLE `event_kon`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_event` (`event_id`),
  ADD KEY `fk_partisipant` (`participant_id`);

--
-- Indexes for table `konten`
--
ALTER TABLE `konten`
  ADD PRIMARY KEY (`id_konten`);

--
-- Indexes for table `partisipant`
--
ALTER TABLE `partisipant`
  ADD PRIMARY KEY (`participant_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `event_kon`
--
ALTER TABLE `event_kon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `konten`
--
ALTER TABLE `konten`
  MODIFY `id_konten` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `partisipant`
--
ALTER TABLE `partisipant`
  MODIFY `participant_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `event_kon`
--
ALTER TABLE `event_kon`
  ADD CONSTRAINT `fk_event` FOREIGN KEY (`event_id`) REFERENCES `event` (`event_id`),
  ADD CONSTRAINT `fk_partisipant` FOREIGN KEY (`participant_id`) REFERENCES `partisipant` (`participant_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
